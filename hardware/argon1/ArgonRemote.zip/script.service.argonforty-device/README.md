# ArgonForty Device Configuration

Install services to manage ArgonForty Devices such as power button and fan speed.

This will also enable gpio-ir, i2c and UART.